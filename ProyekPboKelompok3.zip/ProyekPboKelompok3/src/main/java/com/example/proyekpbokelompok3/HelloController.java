package com.example.proyekpbokelompok3;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.sql.*;


public class HelloController  {
    @FXML
    private TableView <VilCop>table;

    static String driver = "com.mysql.cj.jdbc.Driver";
    static String databaseName = "pboproyek";
    static String url = "jdbc:mysql://localhost:3306/"+databaseName;
    static String user = "root";
    static String password = "";
    private VilCop selectedUpdate;
    private ObservableList<VilCop> data= FXCollections.observableArrayList();


    public void initialize()throws SQLException{
        table.getItems().clear();
        try {
            Connection con = DriverManager.getConnection(url,user,password);
            String query = "select * from fasilitashotel where `status`=0";
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(query);
            int column_count = rs.getMetaData().getColumnCount();
            if(column_count > 0)
            {
                while (rs.next())
                {
                    int id_fasilitas = rs.getInt(1);
                    String nama=rs.getString(2);

                    String deskripsi=rs.getString(3);

                    int harga=rs.getInt(4);

                    data.add(new VilCop(nama,deskripsi,harga,id_fasilitas));
                }
            }
        }

        catch (SQLException e) {
            e.printStackTrace();
        }

        Connection con = DriverManager.getConnection(url, user, password);
        table.setItems(data);
        table.getColumns().get(0).setCellValueFactory(new PropertyValueFactory<>("id_fasilitas"));
        table.getColumns().get(1).setCellValueFactory(new PropertyValueFactory<>("nama_fasilitas"));
        table.getColumns().get(2).setCellValueFactory(new PropertyValueFactory<>("Deskripsi"));
        table.getColumns().get(3).setCellValueFactory(new PropertyValueFactory<>("harga"));

    }

    @FXML
    public void onInsert(){
        HelloApplication app = HelloApplication.getApplicationInstance();
        Stage primarystage = app.getPrimarystage();
        Scene insert = app.getInsert();
        primarystage.setScene(insert);

    }

    @FXML
    public void onBack(){
        HelloApplication app = HelloApplication.getApplicationInstance();
        Stage primarystage = app.getPrimarystage();
        Scene menuutama = app.getMenuutama();
        primarystage.setScene(menuutama);
    }
    @FXML
    public void onDelete()throws SQLException{
        VilCop selected = table.getSelectionModel().getSelectedItem();
        if(selected != null) {
            Alert alert = new Alert(Alert.AlertType.NONE, "Hapus paket dengan Nama: " + selected.getnama_fasilitas() +"?", ButtonType.YES, ButtonType.NO);
            alert.setTitle("Delete Selected");
            alert.showAndWait();

            if(alert.getResult() == ButtonType.YES) {
                try {
                    Connection con2 = HelloApplication.createDatabaseConnection();
                    String query2 = "UPDATE `fasilitashotel` SET `status`=1 where `id_paket`="+selected.getid_fasilitas();
                    Statement st2 = con2.createStatement();
                    st2.executeUpdate(query2);
                }
                catch(ClassNotFoundException e)
                {
                    e.printStackTrace();
                }
                catch (SQLException e) {
                    e.printStackTrace();
                }

                Connection con = DriverManager.getConnection(url,user,password);
                String query = "select * from fasilitashotel";
                Statement st = con.createStatement();
                ResultSet rs = st.executeQuery(query);
                int column_count = rs.getMetaData().getColumnCount();
                if(column_count>0){
                    while(rs.next()){
                        if(rs.getInt(1)==selected.getid_fasilitas()){
                            try {
                                Connection con2 = HelloApplication.createDatabaseConnection();
                                String query2 = "UPDATE `fasilitashotel` SET `status`=1 where `id_paket`="+selected.getid_fasilitas();
                                Statement st2 = con2.createStatement();
                                st2.executeUpdate(query2);
                            }
                            catch(ClassNotFoundException e)
                            {
                                e.printStackTrace();
                            }
                            catch (SQLException e) {
                                e.printStackTrace();
                            }
                            table.setEditable(true);
                            int index = table.getSelectionModel().getSelectedIndex();
                            table.getItems().remove(index);

                        }
                    }
                }

                System.out.println("Paket Deleted");
            }
        }
        else {
            Alert alert = new Alert(Alert.AlertType.NONE, "Tidak ada paket yang dipilih", ButtonType.OK);
            alert.setTitle("Delete Selected");
            alert.showAndWait();
        }
    }
    @FXML
    public void onUpdate()throws SQLException{
        VilCop selected = table.getSelectionModel().getSelectedItem();
        this.selectedUpdate = selected;
        HelloApplication app = HelloApplication.getApplicationInstance();
        Stage primarystage = app.getPrimarystage();
        Scene update = app.getUpdate();

        Update updatecontroller = app.getUpdatescenecontroller();
        TextField nama = new TextField();
        nama.setText(selected.getnama_fasilitas());
        TextArea deskripsi = new TextArea();
        deskripsi.setText(selected.getDeskripsi());
        TextField harga = new TextField();
        harga.setText(""+selected.getharga());

        updatecontroller.setNamaTextField(nama);
        updatecontroller.setDeskripsiTextArea(deskripsi);
        updatecontroller.setHargaTextArea(harga);

        primarystage.setScene(update);
    }
    public VilCop getSelectedUpdate() {
        return selectedUpdate;
    }
}