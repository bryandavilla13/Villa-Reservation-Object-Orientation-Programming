package com.example.proyekpbokelompok3;

import javafx.scene.control.Label;
import javafx.scene.control.TextArea;

public class Mawar extends Villa{

    public Mawar(TextArea villaDesc, Label villaname) {
        super(villaDesc, villaname);
    }
}
