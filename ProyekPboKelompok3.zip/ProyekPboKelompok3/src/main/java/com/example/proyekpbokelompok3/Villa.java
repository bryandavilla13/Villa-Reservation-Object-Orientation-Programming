package com.example.proyekpbokelompok3;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class Villa {
    private ArrayList<Villa> villalist = new ArrayList<>();
    private TextArea VillaDesc ;
    private Label Villaname;


    public void initialize() throws FileNotFoundException {
        try {
            Connection con = HelloApplication.createDatabaseConnection();
            String query = "select * from tipevilla";
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(query);
            int column_count = rs.getMetaData().getColumnCount();
            if(column_count > 0)
            {
                while (rs.next())
                {
                    if(rs.getInt(1)==1){
                        villalist.add(new Mawar(new TextArea(rs.getString(4)),new Label("Villa Mawar")));
                    }else if(rs.getInt(1)==2){
                        villalist.add(new Anggrek(new TextArea(rs.getString(4)),new Label("Villa Anggrek")));
                    }else if(rs.getInt(1)==3){
                        villalist.add(new Melati(new TextArea(rs.getString(4)),new Label("Villa Melati")));
                    }else if(rs.getInt(1)==4){
                        villalist.add(new Lotus(new TextArea(rs.getString(4)),new Label("Villa Lotus")));
                    }else if(rs.getInt(1)==5){
                        villalist.add(new Sakura(new TextArea(rs.getString(4)),new Label("Villa Sakura")));
                    }

                }
            }
        }
        catch(ClassNotFoundException e)
        {
            e.printStackTrace();
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }


    public Villa() {
    }

    public TextArea getVillaDesc() {
        return VillaDesc;
    }


    public Label getVillaname() {
        return Villaname;
    }


    public Villa(TextArea villaDesc, Label villaname) {
        VillaDesc = villaDesc;
        Villaname = villaname;
    }

    public ArrayList<Villa> getVillalist() {
        return villalist;
    }
}
