package com.example.proyekpbokelompok3;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.util.Callback;

import java.sql.*;
import java.time.LocalDate;
import java.time.temporal.ChronoField;
import java.time.temporal.ChronoUnit;

import static java.util.concurrent.TimeUnit.DAYS;

public class Transaksi {

    @FXML
    private TableView<VilCop> table;
    private ObservableList<VilCop> data= FXCollections.observableArrayList();

    static String driver = "com.mysql.cj.jdbc.Driver";
    static String databaseName = "pboproyek";
    static String url = "jdbc:mysql://localhost:3306/"+databaseName;
    static String user = "root";
    static String password = "";

    private int idtipevillayangdipilih;
    private int tarifvilla;
    private int id_packet=0;

    @FXML
    private TextField textFieldNama;
    @FXML
    private TextField textFieldTelp;
    @FXML
    private TextField textFieldKTP;
    @FXML
    private TextField textFieldNomorFasilitas;
    @FXML
    private TextField textFieldHargatotal;


    public void initialize()throws SQLException{
        try {
            Connection con = DriverManager.getConnection(url,user,password);
            String query = "select * from fasilitashotel where `status`=0";
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(query);
            int column_count = rs.getMetaData().getColumnCount();
            if(column_count > 0)
            {
                while (rs.next())
                {
                    int id_fasilitas = rs.getInt(1);
                    String nama=rs.getString(2);

                    String deskripsi=rs.getString(3);

                    int harga=rs.getInt(4);

                    data.add(new VilCop(nama,deskripsi,harga,id_fasilitas));
                }
            }
        }

        catch (SQLException e) {
            e.printStackTrace();
        }

        Connection con = DriverManager.getConnection(url, user, password);
        table.setItems(data);
        table.getColumns().get(0).setCellValueFactory(new PropertyValueFactory<>("id_fasilitas"));
        table.getColumns().get(1).setCellValueFactory(new PropertyValueFactory<>("nama_fasilitas"));
        table.getColumns().get(2).setCellValueFactory(new PropertyValueFactory<>("Deskripsi"));
        table.getColumns().get(3).setCellValueFactory(new PropertyValueFactory<>("harga"));

    }

    @FXML
    public void onBack(){
        HelloApplication app = HelloApplication.getApplicationInstance();
        Stage primarystage = app.getPrimarystage();
        Scene Villa = app.getRooms();
        primarystage.setScene(Villa);
    }
    @FXML
    public void onCheckHargaTotal(){

        HelloApplication app = HelloApplication.getApplicationInstance();
        VillasController v = app.getScenecontroller1();
        long temp = ChronoUnit.DAYS.between(v.getPickeddate1(),v.getPickeddate2());
        int datetotal = (int)temp;
        System.out.println(datetotal);

        VilCop selected = table.getSelectionModel().getSelectedItem();
        int hargatotal = 0;
        hargatotal =hargatotal+tarifvilla*datetotal;


        if(selected!=null) {
            hargatotal = hargatotal + selected.getharga();

            id_packet = selected.getid_fasilitas();
        }
        textFieldHargatotal.setText("" + hargatotal);
    }


    @FXML
    public void onBayar(){
        int id_transaksi=0;
        try {
            Connection con = HelloApplication.createDatabaseConnection();
            String query = "select id_transaksi from transaksi";
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(query);
            int column_count = rs.getMetaData().getColumnCount();
            if(column_count > 0)
            {
                while (rs.next())
                {
                    id_transaksi=rs.getInt(1)+1;
                }
            }
        }
        catch(ClassNotFoundException e)
        {
            e.printStackTrace();
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        HelloApplication app = HelloApplication.getApplicationInstance();
        VillasController v = app.getScenecontroller1();
        String datecheckin = ""+v.getPickeddate1().getDayOfMonth()+"/"+v.getPickeddate1().getMonthValue()+"/"+v.getPickeddate1().getYear();
        String datecheckout = ""+v.getPickeddate2().getDayOfMonth()+"/"+v.getPickeddate2().getMonthValue()+"/"+v.getPickeddate2().getYear();

        try {
            Connection con2 = HelloApplication.createDatabaseConnection();
            String query2 = "INSERT INTO `transaksi` (`nama_customer`, `no_telp`, `no_ktp`, `harga_total`, `tanggal_masuk`, `tanggal_keluar`, `id_paket`, `id_tipevilla`) VALUES ('" + textFieldNama.getText() + "', '" + textFieldTelp.getText() + "', '" + textFieldKTP.getText() + "', '" + textFieldHargatotal.getText() + "', '" + datecheckin + "', '" + datecheckout + "', '" + id_packet + "', '" + idtipevillayangdipilih + "');";
            Statement st2 = con2.createStatement();
            st2.executeUpdate(query2);
        }
        catch(ClassNotFoundException e)
        {
            e.printStackTrace();
        }
        catch (SQLException e) {
            e.printStackTrace();
        }

        System.exit(0);
    }
    public void setIdtipevillayangdipilih(int idtipevillayangdipilih) {
        this.idtipevillayangdipilih = idtipevillayangdipilih;
    }
    public void setTarifvilla(int tarifvilla) {
        this.tarifvilla = tarifvilla;
    }
}
