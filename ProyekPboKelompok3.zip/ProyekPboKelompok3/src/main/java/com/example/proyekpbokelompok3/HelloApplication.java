package com.example.proyekpbokelompok3;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;

public class HelloApplication extends Application {
    final static String driver = "com.mysql.cj.jdbc.Driver";
    final static String url = "jdbc:mysql://localhost:3306/pboproyek?&serverTimezone=UTC";
    final static String user = "root";
    final static String password = "";

    public static Connection createDatabaseConnection() throws ClassNotFoundException, SQLException {

        Class.forName(driver);
        Connection con = DriverManager.getConnection(url, user, password);
        return con;
    }
    private Scene update;
    private Update updatescenecontroller;
    private Scene insert;
    private Insert insertscenecontroller;
    private Scene primaryscene;
    private Stage primarystage;
    private Scene menuutama;
    private Scene transaksi;
    private Transaksi scenecontroller3;
    private MenuUtama scenecontroller2;
    private HelloController scenecontroller;
    private VillasController scenecontroller1;
    private Scene rooms;
    private Villa villa = new Villa();
    private static HelloApplication applicationInstance;

    public Villa getVilla() {
        return villa;
    }

    public void setVilla(Villa villa) {
        this.villa = villa;
    }

    public HelloApplication (){
        applicationInstance = this;
    }
    public Stage getPrimarystage() {
        return primarystage;
    }

    public Scene getTransaksi() {
        return transaksi;
    }


    public Scene getUpdate() {
        return update;
    }


    public Transaksi getScenecontroller3() {
        return scenecontroller3;
    }



    public Scene getPrimaryscene() {
        return primaryscene;
    }


    public HelloController getScenecontroller() {
        return scenecontroller;
    }


    public VillasController getScenecontroller1() {
        return scenecontroller1;
    }


    public Scene getRooms() {
        return rooms;
    }


    public Scene getInsert() {
        return insert;
    }


    public Update getUpdatescenecontroller() {
        return updatescenecontroller;
    }


    public Scene getMenuutama() {
        return menuutama;

    }

    public static HelloApplication getApplicationInstance() {
        return applicationInstance;
    }


    @Override
    public void start(Stage stage) throws IOException,SQLException{
        villa.initialize();
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("hello-view.fxml"));
        primaryscene = new Scene(fxmlLoader.load(), 600, 400);
        scenecontroller = fxmlLoader.getController();

        fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Insert.fxml"));
        insert = new Scene(fxmlLoader.load(),600,400);
        insertscenecontroller = fxmlLoader.getController();

        fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Update.fxml"));
        update = new Scene(fxmlLoader.load(),600,400);
        updatescenecontroller = fxmlLoader.getController();

        fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Villas.fxml"));
        rooms = new Scene(fxmlLoader.load(),600,400);
        scenecontroller1 = fxmlLoader.getController();

        fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("MenuUtama.fxml"));
        menuutama = new Scene(fxmlLoader.load(),600,400);
        scenecontroller2 = fxmlLoader.getController();

        fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Transaksi.fxml"));
        transaksi = new Scene(fxmlLoader.load(),600,448);
        scenecontroller3 = fxmlLoader.getController();

        stage.setTitle("Proyek PBO");
        stage.setScene(menuutama);
        stage.show();

        primarystage = stage;
    }

    public static void main(String[] args) {
        launch();
    }
}