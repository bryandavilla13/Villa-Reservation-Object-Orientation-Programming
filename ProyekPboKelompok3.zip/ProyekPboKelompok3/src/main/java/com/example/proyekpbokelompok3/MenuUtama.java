package com.example.proyekpbokelompok3;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class MenuUtama {
    @FXML
    ImageView imagebackground;
    @FXML
    Button background1;
    @FXML
    Button background2;


    public void initialize() throws FileNotFoundException {
        InputStream stream = new FileInputStream("C:\\sothebys-greece-white-vista-2022-06-23_08-41-47_379331.png");
        Image image = new Image(stream);
        imagebackground.setImage(image);
        this.background1.setStyle("-fx-background-color: #ffffff; ");
        this.background2.setStyle("-fx-background-color: #ffffff; ");
    }
    @FXML
    protected void onBookClick(ActionEvent actionEvent) throws FileNotFoundException {
        HelloApplication app = HelloApplication.getApplicationInstance();
        VillasController a = app.getScenecontroller1();
        a.onBookClick(actionEvent);
    }

    @FXML
    protected void onEdit(){
        HelloApplication app = HelloApplication.getApplicationInstance();
        Stage primarystage =app.getPrimarystage();
        Scene edit = app.getPrimaryscene();
        primarystage.setScene(edit);
    }
}
