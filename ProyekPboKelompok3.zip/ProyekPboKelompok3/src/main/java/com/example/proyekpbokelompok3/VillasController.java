package com.example.proyekpbokelompok3;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import javafx.util.Callback;

import javax.xml.transform.Result;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.ResourceBundle;
public class VillasController   {

    @FXML
    private DatePicker mydate1;
    @FXML
    private TextArea description;
    @FXML
    private DatePicker mydate2;
    @FXML
    private Label RoomType;
    private ObservableList<LocalDate> selectedDates = FXCollections.observableArrayList();
    private ObservableList<LocalDate> selectedDates1 = FXCollections.observableArrayList();
    private ArrayList<LocalDate>selectedDates2 = new ArrayList<>();
    private LocalDate pickeddate1;
    private LocalDate pickeddate2;
    @FXML
    private ImageView imagevilla= new ImageView();
    @FXML
    Button background1;
    @FXML
    Button background2;

    public void ClearDate() {
        selectedDates.clear();
        selectedDates1.clear();
        selectedDates2.clear();
    }
    public void initializes() throws FileNotFoundException {




        LocalDate mindate = LocalDate.now();
        LocalDate maxdate = LocalDate.of(2023, 12, 31);

        mydate1.setOnAction(event -> {
            if(selectedDates.size()>0){
                selectedDates.clear();
            }
            selectedDates.add(mydate1.getValue());
            pickeddate1 = mydate1.getValue();
        }
        );
        mydate2.setOnAction(event->{
            if(selectedDates1.size()>0){
                selectedDates1.clear();
            }
            selectedDates1.add(mydate2.getValue());
            pickeddate2 = mydate2.getValue();
        });

        mydate1.setDayCellFactory(new Callback<DatePicker, DateCell>() {
            @Override
            public DateCell call(DatePicker param) {
                return new DateCell() {
                    @Override
                    public void updateItem(LocalDate item, boolean empty) {
                        super.updateItem(item, empty);
                        setDisable(item.isAfter(maxdate) || item.isBefore(mindate)||selectedDates2.contains(item)||selectedDates.contains(item)||selectedDates1.contains(item));

                        setStyle(item.isAfter(maxdate) || item.isBefore(mindate)||selectedDates2.contains(item)||selectedDates.contains(item)||selectedDates1.contains(item) ? "-fx-background-color: #C06C84;" : "");
                    }
                };
            }
        });

        mydate2.setDayCellFactory(new Callback<DatePicker, DateCell>() {
            @Override
            public DateCell call(DatePicker param) {
                return new DateCell() {
                    @Override
                    public void updateItem(LocalDate item, boolean empty) {
                        super.updateItem(item, empty);
                        setDisable(item.isAfter(maxdate) || item.isBefore(mindate)||selectedDates2.contains(item)||selectedDates.contains(item)||selectedDates1.contains(item));
                        setStyle(item.isAfter(maxdate) || item.isBefore(mindate)||selectedDates2.contains(item)||selectedDates.contains(item)||selectedDates1.contains(item) ? "-fx-background-color: #C06C84;" : "");
                    }
                };
            }
        });
    }


    @FXML
    public void onBookClick(ActionEvent actionEvent) throws FileNotFoundException {
        HelloApplication app = HelloApplication.getApplicationInstance();
        Villa vil = app.getVilla();
        MenuItem menu = (MenuItem) actionEvent.getSource();
        Transaksi t = app.getScenecontroller3();
        if(menu.getText().equalsIgnoreCase("Villa Mawar")) {

            for (int i = 0; i < vil.getVillalist().size(); i++) {
                Villa v = vil.getVillalist().get(i);

                if (v instanceof Mawar) {
                    ArrayList<String> masukMawar=new ArrayList<>();
                    ArrayList<String> keluarMawar=new ArrayList<>();

                    RoomType.setText(v.getVillaname().getText());
                    description.setText(v.getVillaDesc().getText());

                    InputStream stream = new FileInputStream("C:\\image-615x400.jpg");
                    Image image = new Image(stream);
                    imagevilla.setImage(image);
                    this.background1.setStyle("-fx-background-color: #ffffff; ");
                    this.background2.setStyle("-fx-background-color: #ffffff; ");

                    try {
                        Connection con = HelloApplication.createDatabaseConnection();
                        String query = "select tanggal_masuk,tanggal_keluar from transaksi";
                        Statement st = con.createStatement();
                        ResultSet rs = st.executeQuery(query);
                        int column_count = rs.getMetaData().getColumnCount();
                        if(column_count > 0)
                        {
                            while (rs.next())
                            {
                                keluarMawar.add(rs.getString(2));
                                masukMawar.add(rs.getString(1));
                            }
                        }
                    }
                    catch(ClassNotFoundException e)
                    {
                        e.printStackTrace();
                    }
                    catch (SQLException e) {
                        e.printStackTrace();
                    }
                    try {
                        Connection con2 = HelloApplication.createDatabaseConnection();
                        String query2 = "select id_tipevilla,tarif_villa from tipevilla where nama_villa = 'mawar'";
                        Statement st2 = con2.createStatement();
                        ResultSet rs2 = st2.executeQuery(query2);
                        int column_count2 = rs2.getMetaData().getColumnCount();
                        if(column_count2 > 0)
                        {
                            while (rs2.next())
                            {
                                t.setIdtipevillayangdipilih(rs2.getInt(1));
                                t.setTarifvilla(rs2.getInt(2));
                            }
                        }
                    }
                    catch(ClassNotFoundException e)
                    {
                        e.printStackTrace();
                    }
                    catch (SQLException e) {
                        e.printStackTrace();
                    }

                    for(int a=0;a<masukMawar.size();a++){
                        String []tglmasuk = masukMawar.get(a).split("/",0);
                        String []tglkeluar = keluarMawar.get(a).split("/",0);
                        int []tglmaks30 = {4,6,9,11};
                        int[]tglmaks31 = {1,3,5,7,8,10,12};
                        int tglmaks=0;
                        for(int c=0;c<tglmaks31.length;c++){
                            if(Integer.parseInt(tglmasuk[1])==tglmaks31[c]){
                                tglmaks=31;
                            }else if(Integer.parseInt(tglmasuk[1])==2){
                                if(Integer.parseInt(tglmasuk[2])%400==0){
                                    tglmaks=29;
                                }else if(Integer.parseInt(tglmasuk[2])%100!=0&&Integer.parseInt(tglmasuk[2])%4==0){
                                    tglmaks=29;
                                }else tglmaks=28;
                            }
                        }
                        for(int c=0;c<tglmaks30.length;c++){
                            if(Integer.parseInt(tglmasuk[1])==tglmaks30[c]){
                                tglmaks=30;
                            }
                        }

                        if(!tglmasuk[1].equalsIgnoreCase(tglkeluar[1])){

                            for(int b=Integer.parseInt(tglmasuk[0]);b<=tglmaks;b++){
                                selectedDates2.add(LocalDate.of(Integer.parseInt(tglmasuk[2]),Integer.parseInt(tglmasuk[1]),b));
                            }
                            for(int d=1;d<=Integer.parseInt(tglkeluar[0]);d++){
                                selectedDates2.add(LocalDate.of(Integer.parseInt(tglkeluar[2]),Integer.parseInt(tglkeluar[1]),d));
                            }
                        }else {

                            for(int b=Integer.parseInt(tglmasuk[0]);b<=Integer.parseInt(tglkeluar[0]);b++){
                                selectedDates2.add(LocalDate.of(Integer.parseInt(tglmasuk[2]),Integer.parseInt(tglmasuk[1]),b));
                            }
                        }

                    }
                    initializes();
                }
            }
        }else if(menu.getText().equalsIgnoreCase("Villa Anggrek")){
            for (int i = 0; i < vil.getVillalist().size(); i++) {
                Villa v = vil.getVillalist().get(i);
                if (v instanceof Anggrek) {
                    ArrayList<String> masukAnggrek=new ArrayList<>();
                    ArrayList<String> keluarAnggrek=new ArrayList<>();
                    RoomType.setText(v.getVillaname().getText());
                    description.setText(v.getVillaDesc().getText());

                    InputStream stream = new FileInputStream("C:\\1.jpg");
                    Image image = new Image(stream);
                    imagevilla.setImage(image);
                    this.background1.setStyle("-fx-background-color: #ffffff; ");
                    this.background2.setStyle("-fx-background-color: #ffffff; ");

                    try {

                        Connection con = HelloApplication.createDatabaseConnection();
                        String query = "select tanggal_masuk,tanggal_keluar from transaksi where id_tipevilla = '2'";
                        Statement st = con.createStatement();
                        ResultSet rs = st.executeQuery(query);
                        int column_count = rs.getMetaData().getColumnCount();
                        if(column_count > 0)
                        {
                            while (rs.next())
                            {
                                keluarAnggrek.add(rs.getString(2));
                                masukAnggrek.add(rs.getString(1));
                            }
                        }
                    }
                    catch(ClassNotFoundException e)
                    {
                        e.printStackTrace();
                    }
                    catch (SQLException e) {
                        e.printStackTrace();
                    }
                    try {

                        Connection con2 = HelloApplication.createDatabaseConnection();
                        String query2 = "select id_tipevilla,tarif_villa from tipevilla where nama_villa = 'anggrek'";
                        Statement st2 = con2.createStatement();
                        ResultSet rs2 = st2.executeQuery(query2);
                        int column_count2 = rs2.getMetaData().getColumnCount();
                        if(column_count2 > 0)
                        {
                            while (rs2.next())
                            {
                                t.setIdtipevillayangdipilih(rs2.getInt(1));
                                t.setTarifvilla(rs2.getInt(2));
                            }
                        }
                    }
                    catch(ClassNotFoundException e)
                    {
                        e.printStackTrace();
                    }
                    catch (SQLException e) {
                        e.printStackTrace();
                    }

                    for(int a=0;a<masukAnggrek.size();a++){
                        String []tglmasuk = masukAnggrek.get(a).split("/",0);
                        String []tglkeluar = keluarAnggrek.get(a).split("/",0);
                        int []tglmaks30 = {4,6,9,11};
                        int[]tglmaks31 = {1,3,5,7,8,10,12};
                        int tglmaks=0;
                        for(int c=0;c<tglmaks31.length;c++){
                            if(Integer.parseInt(tglmasuk[1])==tglmaks31[c]){
                                tglmaks=31;
                            }else if(Integer.parseInt(tglmasuk[1])==2){
                                if(Integer.parseInt(tglmasuk[2])%400==0){
                                    tglmaks=29;
                                }else if(Integer.parseInt(tglmasuk[2])%100!=0&&Integer.parseInt(tglmasuk[2])%4==0){
                                    tglmaks=29;
                                }else tglmaks=28;
                            }
                        }
                        for(int c=0;c<tglmaks30.length;c++){
                            if(Integer.parseInt(tglmasuk[1])==tglmaks30[c]){
                                tglmaks=30;
                            }
                        }

                        if(!tglmasuk[1].equalsIgnoreCase(tglkeluar[1])){

                            for(int b=Integer.parseInt(tglmasuk[0]);b<=tglmaks;b++){
                                selectedDates2.add(LocalDate.of(Integer.parseInt(tglmasuk[2]),Integer.parseInt(tglmasuk[1]),b));
                            }
                            for(int d=1;d<=Integer.parseInt(tglkeluar[0]);d++){
                                selectedDates2.add(LocalDate.of(Integer.parseInt(tglkeluar[2]),Integer.parseInt(tglkeluar[1]),d));
                            }
                        }else {

                            for(int b=Integer.parseInt(tglmasuk[0]);b<=Integer.parseInt(tglkeluar[0]);b++){
                                selectedDates2.add(LocalDate.of(Integer.parseInt(tglmasuk[2]),Integer.parseInt(tglmasuk[1]),b));
                            }
                        }

                    }
                    initializes();
                }
            }
        }else if(menu.getText().equalsIgnoreCase("Villa Melati")){
            for (int i = 0; i < vil.getVillalist().size(); i++) {
                Villa v = vil.getVillalist().get(i);
                if (v instanceof Melati) {

                    ArrayList<String> masukMelati=new ArrayList<>();
                    ArrayList<String> keluarMelati=new ArrayList<>();
                    RoomType.setText(v.getVillaname().getText());
                    description.setText(v.getVillaDesc().getText());

                    InputStream stream = new FileInputStream("C:\\2.jpg");
                    Image image = new Image(stream);
                    imagevilla.setImage(image);
                    this.background1.setStyle("-fx-background-color: #ffffff; ");
                    this.background2.setStyle("-fx-background-color: #ffffff; ");

                    try {

                        Connection con = HelloApplication.createDatabaseConnection();
                        String query = "select tanggal_masuk,tanggal_keluar from transaksi where id_tipevilla = '3'";
                        Statement st = con.createStatement();
                        ResultSet rs = st.executeQuery(query);
                        int column_count = rs.getMetaData().getColumnCount();
                        if(column_count > 0)
                        {
                            while (rs.next())
                            {
                                keluarMelati.add(rs.getString(2));
                                masukMelati.add(rs.getString(1));
                            }
                        }
                    }
                    catch(ClassNotFoundException e)
                    {
                        e.printStackTrace();
                    }
                    catch (SQLException e) {
                        e.printStackTrace();
                    }
                    try {

                        Connection con2 = HelloApplication.createDatabaseConnection();
                        String query2 = "select id_tipevilla,tarif_villa from tipevilla where nama_villa = 'melati'";
                        Statement st2 = con2.createStatement();
                        ResultSet rs2 = st2.executeQuery(query2);
                        int column_count2 = rs2.getMetaData().getColumnCount();
                        if(column_count2 > 0)
                        {
                            while (rs2.next())
                            {
                                t.setIdtipevillayangdipilih(rs2.getInt(1));
                                t.setTarifvilla(rs2.getInt(2));
                            }
                        }
                    }
                    catch(ClassNotFoundException e)
                    {
                        e.printStackTrace();
                    }
                    catch (SQLException e) {
                        e.printStackTrace();
                    }

                    for(int a=0;a<masukMelati.size();a++){
                        String []tglmasuk = masukMelati.get(a).split("/",0);
                        String []tglkeluar = keluarMelati.get(a).split("/",0);
                        int []tglmaks30 = {4,6,9,11};
                        int[]tglmaks31 = {1,3,5,7,8,10,12};
                        int tglmaks=0;
                        for(int c=0;c<tglmaks31.length;c++){
                            if(Integer.parseInt(tglmasuk[1])==tglmaks31[c]){
                                tglmaks=31;
                            }else if(Integer.parseInt(tglmasuk[1])==2){
                                if(Integer.parseInt(tglmasuk[2])%400==0){
                                    tglmaks=29;
                                }else if(Integer.parseInt(tglmasuk[2])%100!=0&&Integer.parseInt(tglmasuk[2])%4==0){
                                    tglmaks=29;
                                }else tglmaks=28;
                            }
                        }
                        for(int c=0;c<tglmaks30.length;c++){
                            if(Integer.parseInt(tglmasuk[1])==tglmaks30[c]){
                                tglmaks=30;
                            }
                        }

                        if(!tglmasuk[1].equalsIgnoreCase(tglkeluar[1])){

                            for(int b=Integer.parseInt(tglmasuk[0]);b<=tglmaks;b++){
                                selectedDates2.add(LocalDate.of(Integer.parseInt(tglmasuk[2]),Integer.parseInt(tglmasuk[1]),b));
                            }
                            for(int d=1;d<=Integer.parseInt(tglkeluar[0]);d++){
                                selectedDates2.add(LocalDate.of(Integer.parseInt(tglkeluar[2]),Integer.parseInt(tglkeluar[1]),d));
                            }
                        }else {

                            for(int b=Integer.parseInt(tglmasuk[0]);b<=Integer.parseInt(tglkeluar[0]);b++){
                                selectedDates2.add(LocalDate.of(Integer.parseInt(tglmasuk[2]),Integer.parseInt(tglmasuk[1]),b));
                            }
                        }

                    }
                    initializes();
                }
            }
        }else if(menu.getText().equalsIgnoreCase("Villa Lotus")){
            for (int i = 0; i < vil.getVillalist().size(); i++) {
                Villa v = vil.getVillalist().get(i);
                if (v instanceof Lotus) {
                    ArrayList<String> masukLotus=new ArrayList<>();
                    ArrayList<String> keluarLotus=new ArrayList<>();
                    RoomType.setText(v.getVillaname().getText());
                    description.setText(v.getVillaDesc().getText());

                    InputStream stream = new FileInputStream("C:\\3.jpg");
                    Image image = new Image(stream);
                    imagevilla.setImage(image);
                    this.background1.setStyle("-fx-background-color: #ffffff; ");
                    this.background2.setStyle("-fx-background-color: #ffffff; ");

                    try {

                        Connection con = HelloApplication.createDatabaseConnection();
                        String query = "select tanggal_masuk,tanggal_keluar from transaksi where id_tipevilla = '4'";
                        Statement st = con.createStatement();
                        ResultSet rs = st.executeQuery(query);
                        int column_count = rs.getMetaData().getColumnCount();
                        if(column_count > 0)
                        {
                            while (rs.next())
                            {
                                keluarLotus.add(rs.getString(2));
                                masukLotus.add(rs.getString(1));
                            }
                        }
                    }
                    catch(ClassNotFoundException e)
                    {
                        e.printStackTrace();
                    }
                    catch (SQLException e) {
                        e.printStackTrace();
                    }
                    try {

                        Connection con2 = HelloApplication.createDatabaseConnection();
                        String query2 = "select id_tipevilla,tarif_villa from tipevilla where nama_villa = 'lotus'";
                        Statement st2 = con2.createStatement();
                        ResultSet rs2 = st2.executeQuery(query2);
                        int column_count2 = rs2.getMetaData().getColumnCount();
                        if(column_count2 > 0)
                        {
                            while (rs2.next())
                            {
                                t.setIdtipevillayangdipilih(rs2.getInt(1));
                                t.setTarifvilla(rs2.getInt(2));
                            }
                        }
                    }
                    catch(ClassNotFoundException e)
                    {
                        e.printStackTrace();
                    }
                    catch (SQLException e) {
                        e.printStackTrace();
                    }

                    for(int a=0;a<masukLotus.size();a++){
                        String []tglmasuk = masukLotus.get(a).split("/",0);
                        String []tglkeluar = keluarLotus.get(a).split("/",0);
                        int []tglmaks30 = {4,6,9,11};
                        int[]tglmaks31 = {1,3,5,7,8,10,12};
                        int tglmaks=0;
                        for(int c=0;c<tglmaks31.length;c++){
                            if(Integer.parseInt(tglmasuk[1])==tglmaks31[c]){
                                tglmaks=31;
                            }else if(Integer.parseInt(tglmasuk[1])==2){
                                if(Integer.parseInt(tglmasuk[2])%400==0){
                                    tglmaks=29;
                                }else if(Integer.parseInt(tglmasuk[2])%100!=0&&Integer.parseInt(tglmasuk[2])%4==0){
                                    tglmaks=29;
                                }else tglmaks=28;
                            }
                        }
                        for(int c=0;c<tglmaks30.length;c++){
                            if(Integer.parseInt(tglmasuk[1])==tglmaks30[c]){
                                tglmaks=30;
                            }
                        }

                        if(!tglmasuk[1].equalsIgnoreCase(tglkeluar[1])){

                            for(int b=Integer.parseInt(tglmasuk[0]);b<=tglmaks;b++){
                                selectedDates2.add(LocalDate.of(Integer.parseInt(tglmasuk[2]),Integer.parseInt(tglmasuk[1]),b));
                            }
                            for(int d=1;d<=Integer.parseInt(tglkeluar[0]);d++){
                                selectedDates2.add(LocalDate.of(Integer.parseInt(tglkeluar[2]),Integer.parseInt(tglkeluar[1]),d));
                            }
                        }else {

                            for(int b=Integer.parseInt(tglmasuk[0]);b<=Integer.parseInt(tglkeluar[0]);b++){
                                selectedDates2.add(LocalDate.of(Integer.parseInt(tglmasuk[2]),Integer.parseInt(tglmasuk[1]),b));
                            }
                        }

                    }
                    initializes();
                }
            }
        }else if(menu.getText().equalsIgnoreCase("Villa Sakura")){
            for (int i = 0; i < vil.getVillalist().size(); i++) {
                Villa v = vil.getVillalist().get(i);
                if (v instanceof Sakura) {
                    ArrayList<String> masukSakura=new ArrayList<>();
                    ArrayList<String> keluarSakura=new ArrayList<>();
                    RoomType.setText(v.getVillaname().getText());
                    description.setText(v.getVillaDesc().getText());

                    InputStream stream = new FileInputStream("C:\\4.jpg");
                    Image image = new Image(stream);
                    imagevilla.setImage(image);
                    this.background1.setStyle("-fx-background-color: #ffffff; ");
                    this.background2.setStyle("-fx-background-color: #ffffff; ");
                    try {

                        Connection con = HelloApplication.createDatabaseConnection();
                        String query = "select tanggal_masuk,tanggal_keluar from transaksi where id_tipevilla = '5'";
                        Statement st = con.createStatement();
                        ResultSet rs = st.executeQuery(query);
                        int column_count = rs.getMetaData().getColumnCount();
                        if(column_count > 0)
                        {
                            while (rs.next())
                            {
                                keluarSakura.add(rs.getString(2));
                                masukSakura.add(rs.getString(1));
                            }
                        }
                    }
                    catch(ClassNotFoundException e)
                    {
                        e.printStackTrace();
                    }
                    catch (SQLException e) {
                        e.printStackTrace();
                    }
                    try {

                        Connection con2 = HelloApplication.createDatabaseConnection();
                        String query2 = "select id_tipevilla,tarif_villa from tipevilla where nama_villa = 'sakura'";
                        Statement st2 = con2.createStatement();
                        ResultSet rs2 = st2.executeQuery(query2);
                        int column_count2 = rs2.getMetaData().getColumnCount();
                        if(column_count2 > 0)
                        {
                            while (rs2.next())
                            {
                                t.setIdtipevillayangdipilih(rs2.getInt(1));
                                t.setTarifvilla(rs2.getInt(2));
                            }
                        }
                    }
                    catch(ClassNotFoundException e)
                    {
                        e.printStackTrace();
                    }
                    catch (SQLException e) {
                        e.printStackTrace();
                    }

                    for(int a=0;a<masukSakura.size();a++){
                        String []tglmasuk = masukSakura.get(a).split("/",0);
                        String []tglkeluar = keluarSakura.get(a).split("/",0);
                        int []tglmaks30 = {4,6,9,11};
                        int[]tglmaks31 = {1,3,5,7,8,10,12};
                        int tglmaks=0;
                        for(int c=0;c<tglmaks31.length;c++){
                            if(Integer.parseInt(tglmasuk[1])==tglmaks31[c]){
                                tglmaks=31;
                            }else if(Integer.parseInt(tglmasuk[1])==2){
                                if(Integer.parseInt(tglmasuk[2])%400==0){
                                    tglmaks=29;
                                }else if(Integer.parseInt(tglmasuk[2])%100!=0&&Integer.parseInt(tglmasuk[2])%4==0){
                                    tglmaks=29;
                                }else tglmaks=28;
                            }
                        }
                        for(int c=0;c<tglmaks30.length;c++){
                            if(Integer.parseInt(tglmasuk[1])==tglmaks30[c]){
                                tglmaks=30;
                            }
                        }

                        if(!tglmasuk[1].equalsIgnoreCase(tglkeluar[1])){

                            for(int b=Integer.parseInt(tglmasuk[0]);b<=tglmaks;b++){
                                selectedDates2.add(LocalDate.of(Integer.parseInt(tglmasuk[2]),Integer.parseInt(tglmasuk[1]),b));
                            }
                            for(int d=1;d<=Integer.parseInt(tglkeluar[0]);d++){
                                selectedDates2.add(LocalDate.of(Integer.parseInt(tglkeluar[2]),Integer.parseInt(tglkeluar[1]),d));
                            }
                        }else {

                            for(int b=Integer.parseInt(tglmasuk[0]);b<=Integer.parseInt(tglkeluar[0]);b++){
                                selectedDates2.add(LocalDate.of(Integer.parseInt(tglmasuk[2]),Integer.parseInt(tglmasuk[1]),b));
                            }
                        }

                    }
                    initializes();
                }
            }
        }
        Stage primarystage = app.getPrimarystage();
        Scene rooms = app.getRooms();
        primarystage.setScene(rooms);
    }
    @FXML
    public void onBook(){
        HelloApplication app = HelloApplication.getApplicationInstance();
        Stage primarystage = app.getPrimarystage();
        Scene Transaksi = app.getTransaksi();
        Transaksi t = app.getScenecontroller3();
        t.onCheckHargaTotal();
        primarystage.setScene(Transaksi);

    }
    @FXML
    public void onBack(){
        ClearDate();
        HelloApplication app = HelloApplication.getApplicationInstance();
        Stage primarystage = app.getPrimarystage();
        Scene Menuutama = app.getMenuutama();
        primarystage.setScene(Menuutama);
    }

    public LocalDate getPickeddate1() {
        return pickeddate1;
    }

    public LocalDate getPickeddate2() {
        return pickeddate2;
    }

}
