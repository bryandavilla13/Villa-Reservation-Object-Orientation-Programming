package com.example.proyekpbokelompok3;

import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import org.w3c.dom.Text;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class Update {
    @FXML
    private TextField namaTextField;

    @FXML
    private TextArea deskripsiTextArea;
    @FXML
    private TextField hargaTextArea;

    @FXML
    public void onBack(){
        HelloApplication app = HelloApplication.getApplicationInstance();
        Stage primarystage = app.getPrimarystage();
        Scene balik = app.getPrimaryscene();
        primarystage.setScene(balik);
    }

    @FXML
    public void onUpdate()throws SQLException{
        HelloApplication app = HelloApplication.getApplicationInstance();
        HelloController controller = app.getScenecontroller();
        VilCop selected = controller.getSelectedUpdate();

        String nama = namaTextField.getText();
        String deskripsi = deskripsiTextArea.getText();
        String harga = hargaTextArea.getText();

        try {
            Connection con2 = HelloApplication.createDatabaseConnection();
            String query2 = "UPDATE `fasilitashotel` SET `nama_paket` ='"+nama+"', `deskripsi_paket`='"+deskripsi+"', `harga`='"+harga+"' WHERE `id_paket`="+selected.getid_fasilitas();
            Statement st2 = con2.createStatement();
            st2.executeUpdate(query2);
        }
        catch(ClassNotFoundException e)
        {
            e.printStackTrace();
        }
        catch (SQLException e) {
            e.printStackTrace();
        }

        onBack();
        controller.initialize();

    }


    public void setNamaTextField(TextField namaTextField) {
        this.namaTextField.setText(namaTextField.getText());
    }

    public void setDeskripsiTextArea(TextArea deskripsiTextArea) {
        this.deskripsiTextArea.setText(deskripsiTextArea.getText());
    }
    public void setHargaTextArea(TextField hargaTextArea) {
        this.hargaTextArea.setText(hargaTextArea.getText());
    }
}
