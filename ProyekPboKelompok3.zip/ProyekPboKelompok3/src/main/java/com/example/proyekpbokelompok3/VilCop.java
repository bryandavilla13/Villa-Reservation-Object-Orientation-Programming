package com.example.proyekpbokelompok3;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class VilCop {

    public VilCop(){

    }
    public VilCop(String nama_fasilitas,String 	deskripsi_fasilitas,int harga,int id_fasilitas){
        this.setnama_fasilitas(nama_fasilitas);
        this.setharga(harga);
        this.setDeskripsi(	deskripsi_fasilitas);
        this.setid_fasilitas(id_fasilitas);
    }
    private IntegerProperty id_fasilitas;
    public void setid_fasilitas(int value){
        id_fasilitasProperty().set(value);
    }
    public int getid_fasilitas(){
        return id_fasilitasProperty().get();
    }

    public IntegerProperty id_fasilitasProperty(){
        if(id_fasilitas==null) id_fasilitas=new SimpleIntegerProperty(this,"id_fasilitas");
        return id_fasilitas;
    }
    private StringProperty nama_fasilitas;
    public void setnama_fasilitas(String value){
        nama_fasilitasProperty().set(value);
    }
    public String getnama_fasilitas(){
        return nama_fasilitasProperty().get();
    }
    public StringProperty nama_fasilitasProperty(){
        if(nama_fasilitas==null) nama_fasilitas=new SimpleStringProperty(this,"nama_fasilitas");
        return nama_fasilitas;
    }
    private IntegerProperty harga;
    public void setharga(int value){
        hargaProperty().set(value);
    }
    public int getharga(){
        return hargaProperty().get();
    }

    public IntegerProperty hargaProperty(){
        if(harga==null) harga=new SimpleIntegerProperty(this,"harga");
        return harga;
    }

    private StringProperty 	deskripsi_fasilitas;
    public void setDeskripsi(String value){
        deskripsiProperty().set(value);
    }
    public String getDeskripsi(){
        return deskripsiProperty().get();
    }
    public StringProperty deskripsiProperty(){
        if(	deskripsi_fasilitas==null) 	deskripsi_fasilitas=new SimpleStringProperty(this,"deskripsi_fasilitas");
        return 	deskripsi_fasilitas;
    }
}
