package com.example.proyekpbokelompok3;

import javafx.scene.control.Label;
import javafx.scene.control.TextArea;

public class Lotus extends Villa{
    public Lotus(TextArea villaDesc, Label villaname) {
        super(villaDesc, villaname);
    }
}
