package com.example.proyekpbokelompok3;

import javafx.scene.control.Label;
import javafx.scene.control.TextArea;

public class Melati extends Villa{
    public Melati(TextArea villaDesc, Label villaname) {
        super(villaDesc, villaname);
    }
}
