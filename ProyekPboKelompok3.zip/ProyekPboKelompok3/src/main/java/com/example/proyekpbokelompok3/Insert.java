package com.example.proyekpbokelompok3;

import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class Insert {
    @FXML
    private TextField namapaket;
    @FXML
    private TextArea deskripsi;
    @FXML
    private TextField hargaTextField;

    @FXML
    public void onBack(){
        HelloApplication app = HelloApplication.getApplicationInstance();
        Stage primarystage = app.getPrimarystage();
        Scene balik = app.getPrimaryscene();
        primarystage.setScene(balik);
    }
    @FXML
    public void onInsert() throws SQLException {
        String nama = namapaket.getText();
        String desc = deskripsi.getText();
        String harga = hargaTextField.getText();

        try {
            Connection con2 = HelloApplication.createDatabaseConnection();
            String query2 = "INSERT INTO `fasilitashotel` ( `nama_paket`, `deskripsi_paket`, `harga`, `status`) VALUES ('" + nama + "', '" + desc + "', '" + Integer.parseInt(harga) +"', '"+ 0+"');";
            Statement st2 = con2.createStatement();
            st2.executeUpdate(query2);
        }
        catch(ClassNotFoundException e)
        {
            e.printStackTrace();
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        HelloApplication app = HelloApplication.getApplicationInstance();
        HelloController controller = app.getScenecontroller();
        controller.initialize();
        onBack();

    }
}
