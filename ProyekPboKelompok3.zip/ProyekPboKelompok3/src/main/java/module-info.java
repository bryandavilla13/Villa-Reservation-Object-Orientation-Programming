module com.example.proyekpbokelompok3 {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;


    opens com.example.proyekpbokelompok3 to javafx.fxml;
    exports com.example.proyekpbokelompok3;
}