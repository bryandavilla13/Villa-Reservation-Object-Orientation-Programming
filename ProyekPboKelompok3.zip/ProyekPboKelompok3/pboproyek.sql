-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 25, 2023 at 09:05 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pboproyek`
--

-- --------------------------------------------------------

--
-- Table structure for table `fasilitashotel`
--

CREATE TABLE `fasilitashotel` (
  `id_paket` int(11) NOT NULL,
  `nama_paket` varchar(10) NOT NULL,
  `deskripsi_paket` varchar(200) NOT NULL,
  `harga` int(11) NOT NULL,
  `status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `fasilitashotel`
--

INSERT INTO `fasilitashotel` (`id_paket`, `nama_paket`, `deskripsi_paket`, `harga`, `status`) VALUES
(1, 'Gym', 'Gym,Kamar Mandi,Handuk,Jacusi', 50000, 1),
(2, 'Kolam Rena', 'Outdoor & Indoor,\r\nAda Hangat dan dingin,\r\nSauna', 50000, 1),
(4, 'A', 'Disediakan ruangan Billiard \ndengan 5 table billiard , \nruangan ber ac, \nno smoking,', 40000, 1),
(109, 'A', 'Kolam Renang dan Gym', 200000, 1),
(110, 'B3', 'Karaoke dan Kolam Renang', 106000, 1),
(111, 'C', 'Billiard, Kolam Renang, dan Gym', 250000, 0),
(112, 'D', 'Karaoke, Gym, dan Kolam Renang', 200000, 0),
(113, 'E', 'Billiard dan Gym', 150000, 1),
(114, 'Sporty', 'Gym', 75000, 0),
(115, 'Swimming', 'Kolam Renang', 50000, 0),
(116, 'Singing', 'Karaoke', 50000, 0),
(117, 'Ball', 'Billiard', 60000, 0),
(118, 'E', 'Billiard dan Gym', 150000, 0),
(119, 'f1', '1231231', 100000, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tipevilla`
--

CREATE TABLE `tipevilla` (
  `id_tipevilla` int(11) NOT NULL,
  `nama_villa` varchar(50) NOT NULL,
  `tarif_villa` int(11) NOT NULL,
  `deskripsi_tipevilla` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tipevilla`
--

INSERT INTO `tipevilla` (`id_tipevilla`, `nama_villa`, `tarif_villa`, `deskripsi_tipevilla`) VALUES
(1, 'mawar', 6000000, 'Villa ini dengan luas 350m^2. Villa ini dilengkapi dengan 3 kamar tidur di lantai atas dan 1 kamar tidur di lantai bawah. Villa ini dilengkapi dengan 1 toilet di lantai bawah dan 2 toilet di lantai atas.'),
(2, 'anggrek', 8000000, 'Villa ini dengan luas 400m^2. Villa ini dilengkapi dengan 4 kamar dengan 2 kamar King Bed dengan 2 kamar Twin Bed. Kamar ini dilengkapi dengan 4 kamar mandi (2 kamar mandi atas dan 2 kamar bawah).'),
(3, 'melati', 500000, 'Villa ini memiliki luas 300m^2 dilengkapi dengan 2 kamar tidur King Bed dengan 2 kamar tidur Twin Bed. Villa ini terdiri dari 2 lantai dengan 3 kamar mandi (1 kamar mandi di atas dengan 2 kamar mandi di bawah). '),
(4, 'lotus', 3000000, 'Villa ini dengan luas 250m^2. Villa ini dilengkapi dengan 3 kamar (1 kamar King Bed dan 2 kamar Twin). Villa ini juga dilengkapi dengan 2 kamar mandi (1 kamar mandi atas dan 1 kamar mandi bawah).'),
(5, 'sakura', 10000000, 'Villa ini dilengkapi dengan 450m^2. Villa ini dilengkapi dengan 5 kamar tidur (3 kamar Twin Bed dengan 2 kamar King Bed). Villa ini dengan 4 kamar mandi (2 kamar mandi atas dan 2 kamar mandi bawah). ');

-- --------------------------------------------------------

--
-- Table structure for table `transaksi`
--

CREATE TABLE `transaksi` (
  `id_transaksi` int(11) NOT NULL,
  `nama_customer` varchar(50) NOT NULL,
  `no_telp` varchar(50) NOT NULL,
  `no_ktp` varchar(30) NOT NULL,
  `harga_total` int(11) NOT NULL,
  `tanggal_masuk` varchar(10) NOT NULL,
  `tanggal_keluar` varchar(10) NOT NULL,
  `id_paket` int(11) DEFAULT NULL,
  `id_tipevilla` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transaksi`
--

INSERT INTO `transaksi` (`id_transaksi`, `nama_customer`, `no_telp`, `no_ktp`, `harga_total`, `tanggal_masuk`, `tanggal_keluar`, `id_paket`, `id_tipevilla`) VALUES
(5, 'Selly', '0833322134', '3570022989', 3050000, '30/6/2023', '3/7/2023', 1, 1),
(6, 'Yusuf', '081758293305', '357102834028', 1530000, '14/6/2023', '16/6/2023', 4, 4),
(7, 'Vier', '081734910212', '35730512401234', 8050000, '22/6/2023', '24/6/2023', 2, 2),
(22, 'Puput', '0238271923', '18291312', 16200000, '30/6/2023', '2/7/2023', 109, 2),
(23, 'ponita', '0898234578', '6745323893', 1250000, '3/7/2023', '5/7/2023', 111, 3),
(25, 'fernando', '08123461', '357305124231', 12050000, '13/7/2023', '15/7/2023', 115, 1),
(26, 'bun', '23493482', '239423438', 12200000, '18/7/2023', '20/7/2023', 112, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `fasilitashotel`
--
ALTER TABLE `fasilitashotel`
  ADD PRIMARY KEY (`id_paket`);

--
-- Indexes for table `tipevilla`
--
ALTER TABLE `tipevilla`
  ADD PRIMARY KEY (`id_tipevilla`);

--
-- Indexes for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`id_transaksi`),
  ADD KEY `id_paket` (`id_paket`),
  ADD KEY `id_tipevilla` (`id_tipevilla`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `fasilitashotel`
--
ALTER TABLE `fasilitashotel`
  MODIFY `id_paket` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=120;

--
-- AUTO_INCREMENT for table `tipevilla`
--
ALTER TABLE `tipevilla`
  MODIFY `id_tipevilla` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `transaksi`
--
ALTER TABLE `transaksi`
  MODIFY `id_transaksi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD CONSTRAINT `transaksi_ibfk_1` FOREIGN KEY (`id_paket`) REFERENCES `fasilitashotel` (`id_paket`),
  ADD CONSTRAINT `transaksi_ibfk_2` FOREIGN KEY (`id_tipevilla`) REFERENCES `tipevilla` (`id_tipevilla`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
